#include "StudentWorld.h"

// Students:  Add code to this file, Actor.h, StudentWorld.h, and StudentWorld.cpp


////////////////////////////////////////////////////////////////////////////////////////////////////////
////// DERIVED CLASS IMPLEMENTATION - NACHENBLASTER
////////////////////////////////////////////////////////////////////////////////////////////////////////

void NachenBlaster::setHealth(int amount) {
    if (amount > 50)
        m_hitPoints = 50;
    else if (amount <= 0) {
        setDead(true);
        m_hitPoints = 0;
    }
    else
        m_hitPoints = amount;
}

void NachenBlaster::doSomething() {
    
    if (isDead())
        return;
    
    if (collisionCheck())
        return;
    
    moveNachenBlaster();
    
    if ( m_cabbageEnergy < 30)
        m_cabbageEnergy++;
    
    if (collisionCheck())
        return;
}

bool NachenBlaster::collisionCheck() {
    
    if (getWorld()->collidedWithAlien(this, SHIP_KILL_ALIEN))
        return true;
    
    return false;
}



void NachenBlaster::moveNachenBlaster() {
    
    int key;
    if (getWorld()->getKey(key)) {
        
        double xPos = getX();
        double yPos = getY();
        double radius = getRadius();
        
        switch (key) {
            case KEY_PRESS_LEFT:
                xPos -= 6;
                break;
            case KEY_PRESS_UP:
                yPos += 6;
                break;
            case KEY_PRESS_DOWN:
                yPos -=6;
                break;
            case KEY_PRESS_RIGHT:
                xPos += 6;
                break;
            case KEY_PRESS_SPACE:
                if (m_cabbageEnergy < 5) break;
                m_cabbageEnergy -= 5;
                getWorld()->addActor(new Cabbage(getWorld(), getX()+12, getY()), true);
                getWorld()->playSound(SOUND_PLAYER_SHOOT);
                break;
            case KEY_PRESS_TAB:
                if (m_torpedoCount < 1) break;
                m_torpedoCount--;
                getWorld()->addActor(new TorpedoProjectile(getWorld(), getX()+12, getY(), 0), true);
                getWorld()->playSound(SOUND_TORPEDO);
                break;
            default:
                break;
        }
        
        if (xPos >= 0 && xPos-radius < VIEW_WIDTH && yPos+radius >= 0 && yPos-radius < VIEW_HEIGHT) {
            moveTo(xPos, yPos);
        }
        
    }
}

////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////
////// DERIVED BASE CLASS IMPLEMENTATION - ALIEN
////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////


Alien::Alien(StudentWorld* world, int imageID, int startX, int startY, bool isSnagglegon, double travelSpeed) : Actor(world, imageID, startX, startY, true, 0, 1.5, 1), m_speed(travelSpeed), m_isSnagglegon(isSnagglegon) {
    
    if ( ! m_isSnagglegon) {
        m_flightPlanLength = 0;
        m_flightDirection = UNKNOWN;
        m_hitPoints = 5.0 * (1 + (getWorld()->getLevel() - 1) * 0.1);
    }
    
    else {
        m_flightPlanLength = 1;
        m_flightDirection = DOWN_LEFT;
        m_hitPoints = 10 * (1 + (getWorld()->getLevel() - 1) * 0.1);
    }
}

void Alien::decAlienHealth(int howMuch) {
    
    StudentWorld* world = getWorld();
    
    if (m_hitPoints - howMuch < 0) {
        m_hitPoints = 0;
        
        if (m_isSnagglegon)
            world->increaseScore(1000);
        else
            world->increaseScore(250);
        
        if (howMuch == SHIP_KILL_ALIEN) {
            if (m_isSnagglegon)
                world->decNachenBlasterHealth(15);
            else
                world->decNachenBlasterHealth(5);
        }
            
        
        setDead(true);
        world->playSound(SOUND_DEATH);
        world->incDestroyedAlienCount();
        world->addActor(new Explosion(world, getX(), getY()), false);
        dropGoodie();
    }
    
    m_hitPoints -= howMuch;
    world->playSound(SOUND_BLAST);
}

void Alien::doSomething() {
    
    if (isDead())
        return;
    
    if (isOutOfBounds())
        return;
    
    if (collisionCheck())
        return;
    
    newPlanCheck();
    
    if (attackNachenBlaster())
        return;
    
    moveAlien();
    
    if (collisionCheck())
        return;
    
}

void Alien::newPlanCheck() {
    
    int y = getY();
    
    if (y > VIEW_HEIGHT-1)
        m_flightDirection = DOWN_LEFT;
    else if (y < 0)
        m_flightDirection = UP_LEFT;
    
    // unnecessary but used to clarify what is going on here
    if (m_isSnagglegon)
        return;
    
    if (m_flightPlanLength == 0) {
        m_flightDirection = randInt(LEFT, DOWN_LEFT);
        m_flightPlanLength = randInt(1, 32);
    }
}

void Alien::moveAlien() {
    
    if (m_flightDirection == UP_LEFT)
        moveTo(getX()-m_speed, getY()+m_speed);
    else if (m_flightDirection == DOWN_LEFT)
        moveTo(getX()-m_speed, getY()-m_speed);
    else if (m_flightDirection == LEFT)
        moveTo(getX()-m_speed, getY());
    
    if ( ! m_isSnagglegon)
        m_flightPlanLength--;

}

bool Alien::collisionCheck() {
    
    if (getWorld()->collidedWithNachenBlaster(this))
        return true;
    
    return false;
}

bool Alien::attackNachenBlaster() {
    
    if ( getWorld()->NachenBlasterInRange(getX(), getY()) ) {
        
        int chance = randInt(1, (20/getWorld()->getLevel()) + 5);
        if (chance == 1) {
            getWorld()->addActor(new Turnip(getWorld(), getX()-14, getY()), false);
            getWorld()->playSound(SOUND_ALIEN_SHOOT);
            return true;
        }
    }
    
    return false;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////
////// DERIVED CLASS IMPLEMENTATION - SMOREGON
////////////////////////////////////////////////////////////////////////////////////////////////////////

bool Smoregon::attackNachenBlaster() {
    
    if (Alien::attackNachenBlaster())
        return true;
    
    
    if ( getWorld()->NachenBlasterInRange(getX(), getY()) ) {
        
        int chance = randInt(1, (20/getWorld()->getLevel()) + 5);
        if (chance == 1) {
            setFlightDirection(LEFT);
            setPlanLength(VIEW_WIDTH);
            setSpeed(5);
        }
    }
    
    return false;
}

void Smoregon::dropGoodie() {
    
    int chance = randInt(1, 3);
    
    if (chance == 1) {
        
        StudentWorld* world = getWorld();
        
        chance = randInt(1, 2);
        if (chance == 1)
            world->addActor(new Repair(world, getX(), getY()), false);
        else
            world->addActor(new TorpedoGoodie(world, getX(), getY()), false);
    }
}

////////////////////////////////////////////////////////////////////////////////////////////////////////
////// DERIVED CLASS IMPLEMENTATION - SNAGGLEGON
////////////////////////////////////////////////////////////////////////////////////////////////////////

bool Snagglegon::attackNachenBlaster() {
    
    if ( getWorld()->NachenBlasterInRange(getX(), getY()) ) {
        
        int chance = randInt(1, (15/getWorld()->getLevel()) + 10);
        if (chance == 1) {
            getWorld()->addActor(new TorpedoProjectile(getWorld(), getX()-14, getY(), 180), false);
            getWorld()->playSound(SOUND_TORPEDO);
            return true;
        }
    }
    
    return false;
}

void Snagglegon::dropGoodie() {
    
    int chance = randInt(1, 6);
    
    if (chance == 1)
        getWorld()->addActor(new ExtraLife(getWorld(), getX(), getY()), false);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////
////// DERIVED BASE CLASS IMPLEMENTATION - GOODIE
////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////

void Goodie::doSomething() {
    
    if (isDead())
        return;
    
    if (isOutOfBounds())
        return;
    
    if (collisionCheck())
        return;
    
    moveGoodie();
    
    if (collisionCheck())
        return;
}

bool Goodie::collisionCheck() {
    
    StudentWorld* world = getWorld();
    if (getWorld()->collidedWithNachenBlaster(this)) {
        world->increaseScore(100);
        setDead(true);
        world->playSound(SOUND_GOODIE);
        benefit();
        return true;
    }
    
    return false;
}

bool Goodie::isOutOfBounds() {
    
    if (Actor::isOutOfBounds())
        return true;
    
    double y = getY();
    double rad = getRadius();
    
    if ( y+rad < 0 || y-rad > VIEW_HEIGHT-1 ) {
        setDead(true);
        return true;
    }
    
    return false;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////
////// BENEFIT() IMPLEMENTATIONS FOR DERIVED GOODIES
////////////////////////////////////////////////////////////////////////////////////////////////////////

void ExtraLife::benefit() {
    getWorld()->incLives();
}

void Repair::benefit() {
    getWorld()->incNachenBlasterHealth(10);
}

void TorpedoGoodie::benefit() {
    getWorld()->incNachenBlasterTorpedoes(5);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////
////// DERIVED BASE CLASS IMPLEMENTATION - PROJECTILES
////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////

void Projectile::doSomething() {
    
    if (isDead())
        return;
    
    if (isOutOfBounds())
        return;
    
    if (collisionCheck())
        return;
    
    moveProjectile();
    
    if (collisionCheck())
        return;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////
////// COLLISIONCHECK() IMPLEMENTATIONS FOR DERIVED PROJECTILES
////////////////////////////////////////////////////////////////////////////////////////////////////////

bool Cabbage::collisionCheck() {
    
    if (getWorld()->collidedWithAlien(this, 2)) {
        setDead(true);
        return true;
    }
    
    return false;
}

bool Turnip::collisionCheck() {
    
    if (getWorld()->collidedWithNachenBlaster(this)) {
        getWorld()->decNachenBlasterHealth(2);
        getWorld()->playSound(SOUND_BLAST);
        setDead(true);
        return true;
    }
    
    return false;
}

bool TorpedoProjectile::collisionCheck() {
    
    if (getDirection() == 180 && getWorld()->collidedWithNachenBlaster(this)) {
        getWorld()->decNachenBlasterHealth(8);
        getWorld()->playSound(SOUND_BLAST);
        setDead(true);
        return true;
    }
    else if (getWorld()->collidedWithAlien(this, 8)) {
        setDead(true);
        return true;
    }
    
    return false;
}
