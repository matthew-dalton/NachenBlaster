#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"
#include "StudentWorld.h"

class StudentWorld;

////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////
////// ABSTRACT BASE CLASS DECLARATION - ACTOR
////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////

class Actor : public GraphObject {

protected:
    inline Actor(StudentWorld* world, int imageID, double startX, double startY, bool isAlien, int direction = 0, double size = 1.0, int depth = 0) : GraphObject(imageID, startX, startY, direction, size, depth), m_world(world), m_dead(false), m_alien(isAlien) {}
    virtual bool isOutOfBounds();
    inline void setDead(bool dead) { m_dead = dead; }
    inline StudentWorld* getWorld() const { return m_world; }
public:
    virtual void doSomething() = 0;  // function to be implemented by every derived object
    inline bool isAlien() const { return m_alien; }
    inline bool isDead() const { return m_dead; }
private:
    bool m_alien;
    bool m_dead;
    StudentWorld* m_world;
};

inline bool Actor::isOutOfBounds() {
    
    double x = getX();
    double rad = getRadius();
    if ( x+rad < 0 || x-rad > VIEW_WIDTH-1 ) {
        setDead(true);
        return true;
    }
    
    return false;
}


////////////////////////////////////////////////////////////////////////////////////////////////////////
////// DERIVED CLASS DECLARATION - NACHENBLASTER
////////////////////////////////////////////////////////////////////////////////////////////////////////

// PASSED TO DECALIENHEALTH() AS THE VALUE 'HOWMUCH' --> SIGNIFIES THAT THE ALIEN SHIP COLLIDED WITH THE NACHENBLASTER
const int SHIP_KILL_ALIEN = 10000000;

class NachenBlaster : public Actor {
public:
    inline NachenBlaster(StudentWorld* world) : Actor(world, IID_NACHENBLASTER, 0, 128, false), m_hitPoints(50), m_cabbageEnergy(30), m_torpedoCount(0) {}
    virtual void doSomething();
    inline int getHealth() const { return m_hitPoints; }
    inline int getCabbages() const { return m_cabbageEnergy; }
    inline int getTorpedoes() const { return m_torpedoCount; }
    void setHealth(int amount);
    inline void addTorpedoes(int howMany) { m_torpedoCount += howMany; }
private:
    bool collisionCheck();
    void moveNachenBlaster();
    double m_hitPoints;
    int m_cabbageEnergy;
    int m_torpedoCount;
};

////////////////////////////////////////////////////////////////////////////////////////////////////////
////// DERIVED CLASS DECLARATION - STAR
////////////////////////////////////////////////////////////////////////////////////////////////////////

class Star : public Actor {
public:
    inline Star(StudentWorld* world, double size, double startY, double startX = (VIEW_WIDTH-1)) : Actor(world, IID_STAR, startX, startY, false, 0, size, 3) {}
    inline virtual void doSomething() { moveStar(); }
private:
    void moveStar(); // move the star 1 to the left
};

inline void Star::moveStar() {
    moveTo( getX()-1, getY());
    isOutOfBounds();
}


////////////////////////////////////////////////////////////////////////////////////////////////////////
////// DERIVED CLASS DECLARATION - EXPLOSION
////////////////////////////////////////////////////////////////////////////////////////////////////////

class Explosion : public Actor {
public:
    inline Explosion(StudentWorld* world, double startX, double startY) : Actor(world, IID_EXPLOSION, startX, startY, false), m_tickNumber(0) {}
    virtual void doSomething();
private:
    int m_tickNumber;
};

inline void Explosion::doSomething() {
    setSize( getSize()*1.5 );
    if (++m_tickNumber == 4)
        setDead(true);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////
////// DERIVED BASE CLASS DECLARATION - ALIEN
////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////

class Alien : public Actor {
protected:
    Alien(StudentWorld* world, int imageID, int startX, int startY, bool isSnagglegon, double travelSpeed = 2.0);
    void newPlanCheck();
    virtual bool attackNachenBlaster();
    void moveAlien();
    bool collisionCheck();
    virtual void dropGoodie() = 0;
    inline void setFlightDirection(int direction) { m_flightDirection = direction; }
    inline void setPlanLength(int length) { m_flightPlanLength = length; }
    inline void setSpeed(double speed) { m_speed = speed; }
    // KEEP THESE CONSTANTS CONTIGUOUS AND IN THIS ORDER (actual values don't matter)
    const int UNKNOWN = 0;
    const int LEFT = 1;
    const int UP_LEFT = 2;
    const int DOWN_LEFT = 3;
public:
    virtual void doSomething();
    void decAlienHealth(int howMuch);
private:
    double m_speed;
    int m_flightDirection;
    int m_flightPlanLength;
    double m_hitPoints;
    bool m_isSnagglegon;
};

////////////////////////////////////////////////////////////////////////////////////////////////////////
////// DERIVED CLASS DECLARATION - SMALLGON
////////////////////////////////////////////////////////////////////////////////////////////////////////

class Smallgon : public Alien {
public:
    inline Smallgon(StudentWorld* world, double startX, double startY) : Alien(world, IID_SMALLGON, startX, startY, false) {}
private:
    inline virtual void dropGoodie() {}
};

////////////////////////////////////////////////////////////////////////////////////////////////////////
////// DERIVED CLASS DECLARATION - SMOREGON
////////////////////////////////////////////////////////////////////////////////////////////////////////

class Smoregon : public Alien {
public:
    inline Smoregon(StudentWorld* world, double startX, double startY) : Alien(world, IID_SMOREGON, startX, startY, false) {}
private:
    virtual bool attackNachenBlaster();
    virtual void dropGoodie();
};

////////////////////////////////////////////////////////////////////////////////////////////////////////
////// DERIVED CLASS DECLARATION - SNAGGLEGON
////////////////////////////////////////////////////////////////////////////////////////////////////////

class Snagglegon : public Alien {
public:
    inline Snagglegon(StudentWorld* world, double startX, double startY) : Alien(world, IID_SNAGGLEGON, startX, startY, true, 1.75) {}
private:
    virtual bool attackNachenBlaster();
    virtual void dropGoodie();
};

////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////
////// DERIVED BASE CLASS DECLARATION - GOODIE
////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////

class Goodie : public Actor {
protected:
    inline Goodie(StudentWorld* world, int imageID, double startX, double startY) : Actor(world, imageID, startX, startY, false, 0, 0.5, 1) {}
    bool collisionCheck();
    virtual void benefit() = 0;
public:
    virtual void doSomething();
private:
    inline void moveGoodie() { moveTo(getX()-0.75, getY()-0.75); }
    virtual bool isOutOfBounds();
};

////////////////////////////////////////////////////////////////////////////////////////////////////////
////// DERIVED CLASS DECLARATION - EXTRALIFE
////////////////////////////////////////////////////////////////////////////////////////////////////////

class ExtraLife : public Goodie {
public:
    inline ExtraLife(StudentWorld* world, double startX, double startY) : Goodie(world, IID_LIFE_GOODIE, startX, startY) {}
private:
    virtual void benefit();
};

////////////////////////////////////////////////////////////////////////////////////////////////////////
////// DERIVED CLASS DECLARATION - REPAIR
////////////////////////////////////////////////////////////////////////////////////////////////////////

class Repair : public Goodie {
public:
    inline Repair(StudentWorld* world, double startX, double startY) : Goodie(world, IID_REPAIR_GOODIE, startX, startY) {}
private:
    virtual void benefit();
};

////////////////////////////////////////////////////////////////////////////////////////////////////////
////// DERIVED CLASS DECLARATION - TORPEDOGOODIE
////////////////////////////////////////////////////////////////////////////////////////////////////////

class TorpedoGoodie : public Goodie {
public:
    inline TorpedoGoodie(StudentWorld* world, double startX, double startY) : Goodie(world, IID_TORPEDO_GOODIE, startX, startY) {}
private:
    virtual void benefit();
};

////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////
////// DERIVED BASE CLASS DECLARATION - PROJECTILES
////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////

class Projectile : public Actor {
protected:
    inline Projectile(StudentWorld* world, int imageID, double startX, double startY, int direction, double size, int depth) : Actor(world, imageID, startX, startY, false, direction, size, depth) {}
    virtual bool collisionCheck() = 0;
    virtual void moveProjectile() = 0;
public:
    virtual void doSomething();
};

////////////////////////////////////////////////////////////////////////////////////////////////////////
////// DERIVED CLASS DECLARATION - TURNIP
////////////////////////////////////////////////////////////////////////////////////////////////////////

class Turnip : public Projectile {
public:
    inline Turnip(StudentWorld* world, double startX, double startY) : Projectile(world, IID_TURNIP, startX, startY, 0, 0.5, 1) {}
private:
    virtual void moveProjectile();
    virtual bool collisionCheck();
};

inline void Turnip::moveProjectile() {
    moveTo(getX()-6, getY());
    setDirection( getDirection()+20 );
}

////////////////////////////////////////////////////////////////////////////////////////////////////////
////// DERIVED CLASS DECLARATION - CABBAGE
////////////////////////////////////////////////////////////////////////////////////////////////////////

class Cabbage : public Projectile {
public:
    inline Cabbage(StudentWorld* world, double startX, double startY) : Projectile(world, IID_CABBAGE, startX, startY, 0, 0.5, 1) {}
private:
    virtual bool collisionCheck();
    virtual void moveProjectile();
};

inline void Cabbage::moveProjectile() {
    moveTo(getX()+8, getY());
    setDirection( getDirection()+20 );
}

////////////////////////////////////////////////////////////////////////////////////////////////////////
////// DERIVED CLASS DECLARATION - TORPEDOPROJECTILE
////////////////////////////////////////////////////////////////////////////////////////////////////////

class TorpedoProjectile : public Projectile {
public:
    inline TorpedoProjectile(StudentWorld* world, double startX, double startY, int direction) : Projectile(world, IID_TORPEDO, startX, startY, direction, 0.5, 1) {}
private:
    virtual void moveProjectile();
    virtual bool collisionCheck();
};

inline void TorpedoProjectile::moveProjectile() {
    if (getDirection() == 180)  // fired by snagglegon
        moveTo(getX()-8, getY());
    else if (getDirection() == 0)  // fired by NachenBlaster
        moveTo(getX()+8, getY());
}


#endif // ACTOR_H_
