#ifndef STUDENTWORLD_H_
#define STUDENTWORLD_H_



#include "GameWorld.h"
#include "Actor.h"
#include <list>
#include <string>
//using namespace std;  // remove once finished

class Actor;

// Students:  Add code to this file, StudentWorld.cpp, Actor.h, and Actor.cpp

class StudentWorld : public GameWorld
{
public:
    StudentWorld(std::string assetDir) : GameWorld(assetDir), m_ship(nullptr), m_destroyedAliens(0), m_aliensToKill(0) {}
    virtual int init();
    virtual int move();
    virtual void cleanUp();
    inline void incNachenBlasterHealth(int howMuch) { m_ship->setHealth(m_ship->getHealth() + howMuch); }
    inline void decNachenBlasterHealth(int howMuch) { m_ship->setHealth(m_ship->getHealth() - howMuch); }
    inline void incNachenBlasterTorpedoes(int howMuch) { m_ship->addTorpedoes(howMuch); }
    bool collidedWithNachenBlaster(Actor* one);
    bool collidedWithAlien(Actor* one, int howMuch);
    void addActor(Actor* newGuy, bool atFront);
    bool NachenBlasterInRange(double x, double y);
    inline void incDestroyedAlienCount() { m_destroyedAliens++; }
    inline ~StudentWorld() { cleanUp(); }
private:
    std::list<Actor*> m_actors; // container to hold objects
    NachenBlaster* m_ship;  // NachenBlaster is kept separate from other objects
    int m_destroyedAliens;
    int m_aliensToKill;
    int callOnActors();
    void removeDead();
    void addStar();
    void addAlien();
    void statusBar();
    bool collided(Actor* one, Actor* two);
};

///////////////////////////////////////////////////////////////////////////////////////
////// INLINE IMPLEMENTATIONS
///////////////////////////////////////////////////////////////////////////////////////

inline void StudentWorld::addActor(Actor* newGuy, bool atFront) {
    if (atFront)
        m_actors.push_front(newGuy);
    else
        m_actors.push_back(newGuy);
}



#endif // STUDENTWORLD_H_
