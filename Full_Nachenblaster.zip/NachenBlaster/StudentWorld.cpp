#include "StudentWorld.h"
#include "GameConstants.h"
#include <string>
#include <sstream>
//#include <iostream>  // for debugging purposes
using namespace std;

GameWorld* createStudentWorld(string assetDir)
{
	return new StudentWorld(assetDir);
}

// Students:  Add code to this file, StudentWorld.h, Actor.h and Actor.cpp

int StudentWorld::init()
{
    m_ship = new NachenBlaster(this);
    
    // add 30 stars to container
    for (int starNum = 0; starNum < 30; starNum++) {
        
        // get a random number from .5 to .05
        double size = .05 * randInt(1, 10);
        
        // get a random number for x and y
        double y = randInt(0, VIEW_HEIGHT-1);
        double x = randInt(0, VIEW_WIDTH-1);
        
        // push a star with that size and that y coordinate
        m_actors.push_back(new Star(this, size, y, x));
    }
    
    statusBar();
    
    m_destroyedAliens = 0;
    m_aliensToKill = 6 + (4 * getLevel());
    
    return GWSTATUS_CONTINUE_GAME;
}

int StudentWorld::move()
{
    int result = callOnActors();
    
    if (result == GWSTATUS_PLAYER_DIED)
        return result;
    else if (result == GWSTATUS_FINISHED_LEVEL) {
        playSound(SOUND_FINISHED_LEVEL);
        return result;
    }
    
    removeDead();
    
    addStar();
    
    addAlien();
    
    statusBar();
    
    return GWSTATUS_CONTINUE_GAME;
}

void StudentWorld::cleanUp()
{
    // delete NachenBlaster
    if (m_ship != nullptr) {
        delete m_ship;
        m_ship = nullptr;
    }
    
    // delete all dynamically allocated objects
    list<Actor*>::iterator it = m_actors.begin();
    while ( it != m_actors.end() ) {
        delete (*it);
        it = m_actors.erase(it);
    }
    
}

void StudentWorld::statusBar() {
    
    ostringstream oss;
    oss.setf(ios::fixed); oss.precision(0);  // sets precision of doubles to no decimal places
    
    oss << "Lives: " << getLives() << "  Health: " << m_ship->getHealth()*2
    << "%  Score: " << getScore() << "  Level: " << getLevel()
    << "  Cabbages: " << m_ship->getCabbages()/0.3 << "%  Torpedoes: " << m_ship->getTorpedoes();
    
    setGameStatText(oss.str());
    
}

bool StudentWorld::NachenBlasterInRange(double x, double y) {
    
    double shipX = m_ship->getX();
    double shipY = m_ship->getY();
    
    if (shipX < x && shipY >= y-4 && shipY <= y+4)
        return true;
    
    return false;
}

int StudentWorld::callOnActors() {
    
    // NachenBlaster will never be dead here
    m_ship->doSomething();
    
    if (m_destroyedAliens == m_aliensToKill)
        return GWSTATUS_FINISHED_LEVEL;
    
    // call doSomething on every object
    for (list<Actor*>::iterator it = m_actors.begin(); it != m_actors.end(); it++) {
        if ( ! (*it)->isDead())
            (*it)->doSomething();
        if (m_ship->isDead()) {
            decLives();
            return GWSTATUS_PLAYER_DIED;
        }
        
        // check if level is over
        if (m_destroyedAliens == m_aliensToKill)
            return GWSTATUS_FINISHED_LEVEL;
    }
    
    return GWSTATUS_CONTINUE_GAME;
}

void StudentWorld::removeDead() {
    
    // remove all dead objects from the list
    list<Actor*>::iterator it = m_actors.begin();
    while ( it != m_actors.end() ) {
        if( (*it)->isDead() ) {
            delete (*it);
            it = m_actors.erase(it);
        }
        else
            it++;
    }
}

void StudentWorld::addStar() {
    
    // add new stars to the list with a 1 in 15 chance
    int chance = randInt(1, 15);
    if (chance == 1) {
        
        // randomly generate size and y coordinate
        double size = .05 * randInt(1, 10);
        double y = randInt(0, VIEW_HEIGHT-1);
        
        // add new star to container
        m_actors.push_back(new Star(this, size, y));
    }
}

void StudentWorld::addAlien() {
    
    int remainder = m_aliensToKill - m_destroyedAliens;
    int max = 4 + (0.5*getLevel());
    int min = max;
    if (remainder < min)
        min = remainder;
    
    int alienCount = 0;
    for (list<Actor*>::iterator it = m_actors.begin(); it != m_actors.end(); it++)
        if ( (*it)->isAlien() )
            alienCount++;
    
    if (alienCount < min) {
        
        int a = 60;
        int b = 20 + getLevel()*5;
        int c = 5 + getLevel()*10;
        int d = a+b+c;
        int chance = randInt(1, d);
        
        double y = randInt(0, VIEW_HEIGHT-1);
        double x = VIEW_WIDTH-1;
        
        if ( chance < a )  // add a smallgon
            m_actors.push_back(new Smallgon(this, x, y));
        else if ( chance < a + b )  // add a smoregon
            m_actors.push_back(new Smoregon(this, x, y));
        else  // add a snagglegon
            m_actors.push_back(new Snagglegon(this, x, y));
    }
    
}

bool StudentWorld::collidedWithNachenBlaster(Actor* one) {
    
    bool hit = collided(one, m_ship);
    
    if ( ! one->isAlien())
        return hit;

    if (hit) {
        Alien* alien = static_cast<Alien*>(one);
        alien->decAlienHealth(SHIP_KILL_ALIEN);
    }
    
    return false;
}

bool StudentWorld::collidedWithAlien(Actor* one, int howMuch) {
    
    // loop to go through m_actors
    for (list<Actor*>::iterator it = m_actors.begin(); it != m_actors.end(); it++)
        if ((*it)->isAlien() && collided(one, (*it))) {
            Alien* alien = static_cast<Alien*>(*it);
            alien->decAlienHealth(howMuch);
            return true;
        }
    
    return false;
}

bool StudentWorld::collided(Actor* one, Actor* two) {
    double x1 = one->getX();
    double y1 = one->getY();
    double r1 = one->getRadius();
    double x2 = two->getX();
    double y2 = two->getY();
    double r2 = two->getRadius();
    
    double distanceSquared = (x2-x1)*(x2-x1) + (y2-y1)*(y2-y1);
    double comparison = 0.75*(r1+r2);
    comparison *= comparison;
    
    if (distanceSquared < comparison)
        return true;
    
    return false;
}
